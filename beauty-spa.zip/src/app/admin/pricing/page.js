import Pricing from "@/components/admin/Pricing";

export default function Home() {
  return (
    <>
      <Pricing />
    </>
  );
}
