export default function notFound() {
  return (
    <>
      <h1>404 Not Found</h1>
    </>
  );
}
