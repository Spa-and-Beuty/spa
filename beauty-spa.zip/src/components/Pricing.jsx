export const Pricing = () => {
  return <div></div>;
};
