"use client";
import React, { useEffect, useState } from "react";
import AddProductDetail from "./AddProductDetail";
// import { getManyCategories } from "@/data/categories";

export default function AddProducts() {
  // const categories = await getManyCategories()
  // console.log("categories", categories);
  return <AddProductDetail />;
}
